import React,{Component} from 'react'

export default class ChangeTextCaseWithTheme extends Component
{
    constructor()
    {
        super();
        this.state={
            text:'',
            theme:'light'//default theme
            
        };
        this.handleChange=this.handleChange.bind(this);
        this.changeTextToLowerCase=this.changeTextToLowerCase.bind(this);
        this.changeTextToUpperCase=this.changeTextToUpperCase.bind(this);
        this.toggleTheme=this.toggleTheme.bind(this);
    }
    handleChange(event)
    {
        this.setState({text:event.target.value});
    }
    changeTextToLowerCase()
    {
        this.setState({text:this.state.text.toLowerCase()});
    }
    changeTextToUpperCase()
    {
        this.setState({text:this.state.text.toUpperCae()});
    }
    toggleTheme()
    {
        this.setState((prevState))=>({
            theme:prevState.theme==
        })
    }
}
function Projects() {
  return (
    <div>Projects</div>
  )
}

export default Projects