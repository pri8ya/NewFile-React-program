import React from 'react';

function Footer() {
  return (
    <div>
      <footer className="bg-dark text-white py-4 mt-5">
        <div className="container text-center">
          <div className="row">
            <div className="col-md-6">
              <blockquote className="blockquote">
                <p>"The best way to predict the future is to create it."</p>
                <footer className="blockquote-footer">
                  Peter Drucker, <cite title="Source Title">Source Title</cite>
                </footer>
              </blockquote>
            </div>
            <div className="col-md-6">
              <p>Connect with me:</p>
              <ul className="list-unstyled">
                <li><a href="https://www.linkedin.com" target="_blank" className="text-white">LinkedIn</a></li>
                <li><a href="https://github.com" target="_blank" className="text-white">GitHub</a></li>
                <li><a href="mailto:your-email@example.com" className="text-white">Email</a></li>
              </ul>
            </div>
          </div>
          <hr />
          <p>&copy; 2024 Your Name. All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default Footer;
