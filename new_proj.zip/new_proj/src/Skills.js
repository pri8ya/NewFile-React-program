import React from 'react';

function Skills() {
  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">My Skills</h2>
      <div className="row">
        <div className="col-md-6">
          <h4>Frontend Development</h4>
          <ul className="list-group">
            <li className="list-group-item">HTML & CSS</li>
            <li className="list-group-item">JavaScript</li>
            <li className="list-group-item">React</li>
            <li className="list-group-item">Bootstrap</li>
           
          </ul>
        </div>
        <div className="col-md-6">
          <h4>Backend Development</h4>
          <ul className="list-group">
            <li className="list-group-item">Node.js</li>
            <li className="list-group-item">Java</li>
            <li className="list-group-item">MongoDB</li>
            <li className="list-group-item">MySQL</li>
           
          </ul>
        </div>
      </div>
      <div className="row mt-4">
        <div className="col-md-12">
          <h4>Tools & Technologies</h4>
          <ul className="list-group">
            <li className="list-group-item">Git & GitHub</li>
            
            <li className="list-group-item">AWS</li>
          
           
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Skills;
